fetch('data/plants.json').then(r=>r.json()).then(d=>{
 if(location.pathname.ends_with('plants.html')){
   const ul=document.getElementById('plant-list');
   d.forEach(p=>{ul.innerHTML+=`<li><a href="plant.html?slug=${p.slug}">${p.name}</a></li>`});
 } else {
   const params=new URLSearchParams(location.search);
   const plant=d.find(p=>p.slug===params.get('slug'));
   if(plant){document.getElementById('name').textContent=plant.name;
     document.getElementById('desc').textContent=plant.desc;}
 }
});